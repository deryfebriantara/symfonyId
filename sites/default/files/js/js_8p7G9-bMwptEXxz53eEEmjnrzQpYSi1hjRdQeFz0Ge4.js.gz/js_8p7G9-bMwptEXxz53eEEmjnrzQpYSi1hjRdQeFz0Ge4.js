/**
 * @file
 * JavaScript for the Disqus Drupal module.
 */

// The Disqus global variables.
var disqus_shortname = '';
var disqus_url = '';
var disqus_title = '';
var disqus_identifier = '';
var disqus_disable_mobile = 0;
var disqus_def_name = '';
var disqus_def_email = '';
var disqus_config;

(function ($) {

"use strict";

Drupal.disqus = {};

/**
 * Drupal Disqus behavior.
 */
Drupal.behaviors.disqus = {
  attach: function (context, settings) {
    $('body').once('disqus').each(function() {
      // Load the Disqus comments.
      if (settings.disqus || false) {
        // Setup the global JavaScript variables for Disqus.
        disqus_shortname = settings.disqus.domain;
        disqus_url = settings.disqus.url;
        disqus_title = settings.disqus.title;
        disqus_identifier = settings.disqus.identifier;
        disqus_disable_mobile = settings.disqus.disable_mobile || 0;
        disqus_def_name = settings.disqus.name || '';
        disqus_def_email = settings.disqus.email || '';

        // Language and SSO settings are passed in through disqus_config().
        disqus_config = function() {
          if (settings.disqus.language || false) {
            this.language = settings.disqus.language;
          }
          if (settings.disqus.remote_auth_s3 || false) {
            this.page.remote_auth_s3 = settings.disqus.remote_auth_s3;
          }
          if (settings.disqus.api_key || false) {
            this.page.api_key = settings.disqus.api_key;
          }
          if (settings.disqus.sso || false) {
            this.sso = settings.disqus.sso;
          }
          if (settings.disqus.callbacks || false) {
            for (var key in settings.disqus.callbacks) {
              for (var i = 0; i < settings.disqus.callbacks[key].length; i++) {
                var callback = settings.disqus.callbacks[key][i].split('.');
                var fn = window;
                for (var j = 0; j < callback.length; j++) {
                  fn = fn[callback[j]];
                }
                if(typeof fn === 'function') {
                  this.callbacks[key].push(fn);
                }
              }
            }
          }
        };

        // Make the AJAX call to get the Disqus comments.
        jQuery.ajax({
          type: 'GET',
          url: '//' + disqus_shortname + '.disqus.com/embed.js',
          dataType: 'script',
          cache: false
        });
      }

      // Load the comment numbers JavaScript.
      if (settings.disqusComments || false) {
        disqus_shortname = settings.disqusComments;
        // Make the AJAX call to get the number of comments.
        jQuery.ajax({
          type: 'GET',
          url: '//' + disqus_shortname + '.disqus.com/count.js',
          dataType: 'script',
          cache: false
        });
      }
    });
  }
};

})(jQuery);
;
/**
 * @file
 * Javascript for disqus configuration form.
 */

(function ($) {

"use strict";

Drupal.behaviors.disqusSettingsForm = {
  attach: function (context) {
    var $context = $(context);

    $context.find('#edit-visibility').drupalSetSummary(function(context) {
      var vals = [];

      $('#edit-disqus-nodetypes div.form-type-checkbox').each(function(){
        var vals_node_types = [];
        if ($(this).find('input').is(':checked')) {
          vals_node_types.push(Drupal.checkPlain($(this).find('label').text()));
        }

        if (vals_node_types.length) {
          vals.push($('label[for="edit-disqus-nodetypes"]').text() + ': ' + vals_node_types.join(', '));
        }
      });

      vals.push(Drupal.t('Location: ') + Drupal.checkPlain($('#edit-disqus-location').val()));
      vals.push(Drupal.t('Weight: ') + Drupal.checkPlain($('#edit-disqus-weight').val()));

      return vals.join('<br />');
    });

    $context.find('#edit-behavior').drupalSetSummary(function(context) {
      var vals = [];

      if ($('#edit-disqus-userapikey').val()) {
        vals.push($('#edit-disqus-userapikey').parent().find('label').text());
      }

      var checkboxes = ['#edit-disqus-localization', '#edit-disqus-inherit-login', '#edit-disqus-disable-mobile'];
      for (var i in checkboxes) {
        if ($(checkboxes[i]).is(':checked')) {
          vals.push($(checkboxes[i]).parent().find('label').text());
        }
      }

      return vals.join(', ');
    });

    $context.find('#edit-advanced').drupalSetSummary(function(context) {
      var vals = [];

      if ($('#edit-disqus-publickey').val()) {
        vals.push($('#edit-disqus-publickey').parent().find('label').text());
      }

      if ($('#edit-disqus-secretkey').val()) {
        vals.push($('#edit-disqus-secretkey').parent().find('label').text());
      }

      return vals.join(', ');
    });
  }
};

})(jQuery);
;
